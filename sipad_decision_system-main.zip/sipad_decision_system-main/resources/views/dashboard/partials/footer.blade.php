<footer class="sticky-footer bg-white">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span>Copyright &copy; <a href="https://www.instagram.com/sip_adv/" target="_BLANK">Sinar Indah Padma 2023</a></span>
      </div>
    </div>
  </footer>